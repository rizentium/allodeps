//import 'package:flutter/widgets.dart';
//
//
//
///// Created by andy.pangaribuan on 18/05/2019
///// Copyright CT Corp Digital. All rights reserved.
///// -----------------------------------------------
//class TDBorderRadius {
//  static BorderRadius circularOnly({topLeft: 0.0, topRight: 0.0, bottomLeft: 0.0, bottomRight: 0.0}) =>
//      BorderRadius.only(
//        topLeft: Radius.circular(topLeft),
//        topRight: Radius.circular(topRight),
//        bottomLeft: Radius.circular(bottomLeft),
//        bottomRight: Radius.circular(bottomRight),);
//}
