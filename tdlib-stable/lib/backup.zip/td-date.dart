//import 'package:intl/intl.dart';
//
//
//
///// Created by andy.pangaribuan on 19/06/2019
///// Copyright CT Corp Digital. All rights reserved.
///// -----------------------------------------------
//class TDDate {
//
////  final full1 = _DateUtil('yyyy-MM-dd HH:mm:ss');
////  final full2 = _DateUtil('yyyyMMddHHmmss');
////  final full3 = _DateUtil('yyyyMMddHHmmsss');
//
//  final full = _DateUtil('yyyy-MM-dd HH:mm:ss');
//  final fullMicro = _DateUtil("yyyy-MM-dd HH:mm:ss.SSSSSS");
//
//  DateTime get nowUtc => DateTime.parse(DateTime.now().toUtc().toString().replaceAll("Z", "").replaceAll("z", ""));
//
////  final y4m2d2 = _DateUtil('yyyyMMdd');
////  final y4m2d2T1 = _DateUtil('yyyy-MM-dd');
////
////  final y4m3d2 = _DateUtil('yyyy MMM dd');
////
////  final d2m3y4 = _DateUtil('dd MMM yyyy');
//
//
//
//  String toStr(String format, DateTime dt) {
//    return _DateUtil(format).toStr(dt);
//  }
//
//  DateTime toDate(String format, String value) {
//    return _DateUtil(format).toDate(value);
//  }
//
//}
//
//
//
//class _DateUtil {
//
//  String _format;
//  DateFormat _dtFormat;
//
//  _DateUtil(String format) {
//    _format = format;
//    _dtFormat = DateFormat(_format);
//  }
//
//
//  String toStr(DateTime dt) {
//    switch (_format) {
//      case "yyyy-MM-dd HH:mm:ss.SSSSSS":
//        String date = dt.toIso8601String().replaceAll("T", " ").replaceAll("Z", "");
//        final arr = date.split(".");
//        if (arr.length == 1) {
//          date += ".000000";
//        } else if (arr[1].length != 6) {
//          String ms = arr[1];
//          while (ms.length != 6) {
//            ms += "0";
//          }
//          date = date.replaceFirst("." + arr[1], "." + ms);
//        }
//        return date;
//      default: return _dtFormat.format(dt);
//    }
//  }
//
//  DateTime toDate(String dt) {
//    if (_format == "yyyy-MM-dd HH:mm:ss.SSSSSS") {
//      return DateTime.parse(dt.replaceAll(" ", "T"));
//    }
//
////    if (_format == 'yyyyMMddHHmmsss') {
////      final dt1 = dt.substring(0, 4);
////      final dt2 = dt.substring(4, 6);
////      final dt3 = dt.substring(6, 8);
////      final dt4 = dt.substring(8, 10);
////      final dt5 = dt.substring(10, 12);
////      final dt6 = dt.substring(12, 14);
////      final dt7 = dt.substring(14, 17);
////
////      return DateTime.parse('$dt1-$dt2-$dt3 $dt4:$dt5:$dt6.${dt7}000z');
////    }
//
//    return _dtFormat.parse(dt);
//  }
//
//}
