//
///// Created by andy.pangaribuan on 28/04/2020
///// Copyright CT Corp Digital. All rights reserved.
///// -----------------------------------------------
//
//extension TDIterable<E> on Iterable<E> {
//
//  Iterable<T> mapIndex<T>(T f(int i, E e)) {
//    var i = 0;
//    return this.map((e) => f(i++, e));
//  }
//
//  void forEachIndex(void f(int i, E e)) {
//    var i = 0;
//    this.forEach((e) => f(i++, e));
//  }
//
//}
//
