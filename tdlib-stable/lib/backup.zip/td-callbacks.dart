//
///// Created by andy.pangaribuan on 16/05/2019
///// Copyright CT Corp Digital. All rights reserved.
///// -----------------------------------------------
//
//typedef  TDMuple3Callback<T> = Future<void> Function(T value);
//
//typedef TDWhileTrueAsyncCallbackLoop = Function(bool loopAgain);
//typedef TDWhileTrueAsyncCallback = Future<void> Function(TDWhileTrueAsyncCallbackLoop loop);
//
